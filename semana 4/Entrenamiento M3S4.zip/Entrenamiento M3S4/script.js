//Capturar los datos del formulario y guardar en Local Storage

document.addEventListener("DOMContentLoaded"),()=> {
    const form= document.getElementById("form-register");
    if(!form) return;

}
